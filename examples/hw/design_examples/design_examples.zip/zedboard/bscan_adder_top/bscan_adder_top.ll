Revision 3
; Created by bitgen 2025.2 at Tue Oct  6 15:27:27 2026
; Bit lines have the following form:
; <offset> <frame address> <frame offset> <information>
; <information> may be zero or more <kw>=<value> pairs
; Block=<blockname     specifies the block associated with this
;                      memory cell.
;
; Latch=<name>         specifies the latch associated with this memory cell.
;
; Net=<netname>        specifies the user net associated with this
;                      memory cell.
;
; COMPARE=[YES | NO]   specifies whether or not it is appropriate
;                      to compare this bit position between a
;                      "program" and a "readback" bitstream.
;                      If not present the default is NO.
;
; Ram=<ram id>:<bit>   This is used in cases where a CLB function
; Rom=<ram id>:<bit>   generator is used as RAM (or ROM).  <Ram id>
;                      will be either 'F', 'G', or 'M', indicating
;                      that it is part of a single F or G function
;                      generator used as RAM, or as a single RAM
;                      (or ROM) built from both F and G.  <Bit> is
;                      a decimal number.
;
; Info lines have the following form:
; Info <name>=<value>  specifies a bit associated with the LCA
;                      configuration options, and the value of
;                      that bit.  The names of these bits may have
;                      special meaning to software reading the .ll file.
;
Info STARTSEL0=1
Info BoundaryScanEnabled=1
Bit 11845411 0x00400f9f    131 Block=SLICE_X46Y52 Latch=AQ Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[0]
Bit 11845412 0x00400f9f    132 Block=SLICE_X47Y52 Latch=AQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[0]
Bit 11845414 0x00400f9f    134 Block=SLICE_X46Y52 Latch=A5FF.Q Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[4]
Bit 11845430 0x00400f9f    150 Block=SLICE_X46Y52 Latch=B5FF.Q Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[5]
Bit 11845436 0x00400f9f    156 Block=SLICE_X46Y52 Latch=BQ Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[1]
Bit 11845437 0x00400f9f    157 Block=SLICE_X47Y52 Latch=BQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[5]
Bit 11845441 0x00400f9f    161 Block=SLICE_X46Y52 Latch=CQ Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[2]
Bit 11845442 0x00400f9f    162 Block=SLICE_X47Y52 Latch=CQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[6]
Bit 11845466 0x00400f9f    186 Block=SLICE_X46Y52 Latch=DQ Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[3]
Bit 11845467 0x00400f9f    187 Block=SLICE_X47Y52 Latch=DQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[7]
Bit 11845539 0x00400f9f    259 Block=SLICE_X46Y54 Latch=AQ Net=bscan_u2_simplex_adder_res/bscan_interface_read_write_uX/ux_tdo
Bit 11845542 0x00400f9f    262 Block=SLICE_X46Y54 Latch=A5FF.Q Net=bscan_u2_simplex_adder_res/bscan_interface_read_write_uX/p_2_in
Bit 11845558 0x00400f9f    278 Block=SLICE_X46Y54 Latch=B5FF.Q Net=bscan_u2_simplex_adder_res/bscan_interface_read_write_uX/p_1_in
Bit 11845564 0x00400f9f    284 Block=SLICE_X46Y54 Latch=BQ Net=bscan_u2_simplex_adder_res/bscan_interface_read_write_uX/p_0_in
Bit 11845603 0x00400f9f    323 Block=SLICE_X46Y55 Latch=AQ Net=bscan_u2_simplex_adder_res/bscan_interface_read_write_uX/data_user_reg_data_out_reg_n_0_[4]
Bit 11961763 0x0040101f    131 Block=SLICE_X48Y52 Latch=AQ Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[6]
Bit 11729060 0x00400f1f    132 Block=SLICE_X45Y52 Latch=AQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[1]
Bit 11729085 0x00400f1f    157 Block=SLICE_X45Y52 Latch=BQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[2]
Bit 11729090 0x00400f1f    162 Block=SLICE_X45Y52 Latch=CQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[3]
Bit 11729115 0x00400f1f    187 Block=SLICE_X45Y52 Latch=DQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[4]
Bit 13081059 0x0040151f   1155 Block=SLICE_X64Y68 Latch=AQ Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[7]
Bit 12291363 0x0040119f     67 Block=SLICE_X52Y51 Latch=AQ Net=bscan_u3_tmr_adder_res/bscan_interface_read_write_uX/ux_tdo
Bit 12291366 0x0040119f     70 Block=SLICE_X52Y51 Latch=A5FF.Q Net=bscan_u3_tmr_adder_res/bscan_interface_read_write_uX/p_2_in
Bit 12291382 0x0040119f     86 Block=SLICE_X52Y51 Latch=B5FF.Q Net=bscan_u3_tmr_adder_res/bscan_interface_read_write_uX/p_1_in
Bit 12291388 0x0040119f     92 Block=SLICE_X52Y51 Latch=BQ Net=bscan_u3_tmr_adder_res/bscan_interface_read_write_uX/p_0_in
Bit 12291427 0x0040119f    131 Block=SLICE_X52Y52 Latch=AQ Net=bscan_u3_tmr_adder_res/bscan_interface_read_write_uX/data_user_reg_data_out_reg_n_0_[4]
Bit 14109636 0x0040199f   1956 Block=SLICE_X81Y80 Latch=AQ Net=bscan_u1_operands/bscan_interface_read_write_uX/FSM_onehot_check_rw_reg_n_0_[1]
Bit 14109637 0x0040199f   1957 Block=SLICE_X81Y80 Latch=A5FF.Q Net=bscan_u1_operands/bscan_interface_read_write_uX/FSM_onehot_check_rw_reg_n_0_[2]
Bit 14109661 0x0040199f   1981 Block=SLICE_X81Y80 Latch=BQ Net=bscan_u1_operands/bscan_interface_read_write_uX/FSM_onehot_check_rw_reg_n_0_[0]
Bit 14109666 0x0040199f   1986 Block=SLICE_X81Y80 Latch=CQ Net=bscan_u1_operands/bscan_interface_read_write_uX/rw_reg_0
