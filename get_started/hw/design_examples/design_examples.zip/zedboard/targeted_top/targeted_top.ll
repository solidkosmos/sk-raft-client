Revision 3
; Created by bitgen 2025.2 at Tue Oct 20 01:24:40 2026
; Bit lines have the following form:
; <offset> <frame address> <frame offset> <information>
; <information> may be zero or more <kw>=<value> pairs
; Block=<blockname     specifies the block associated with this
;                      memory cell.
;
; Latch=<name>         specifies the latch associated with this memory cell.
;
; Net=<netname>        specifies the user net associated with this
;                      memory cell.
;
; COMPARE=[YES | NO]   specifies whether or not it is appropriate
;                      to compare this bit position between a
;                      "program" and a "readback" bitstream.
;                      If not present the default is NO.
;
; Ram=<ram id>:<bit>   This is used in cases where a CLB function
; Rom=<ram id>:<bit>   generator is used as RAM (or ROM).  <Ram id>
;                      will be either 'F', 'G', or 'M', indicating
;                      that it is part of a single F or G function
;                      generator used as RAM, or as a single RAM
;                      (or ROM) built from both F and G.  <Bit> is
;                      a decimal number.
;
; Info lines have the following form:
; Info <name>=<value>  specifies a bit associated with the LCA
;                      configuration options, and the value of
;                      that bit.  The names of these bits may have
;                      special meaning to software reading the .ll file.
;
Info STARTSEL0=1
Bit 17038854 0x0042019f   2982 Block=SLICE_X2Y46 Latch=A5FF.Q Net=clk_gen_inst/seq_reg_reg_n_0_[7]
Bit 17042080 0x004201a0   2976 Block=SLICE_X2Y46 Ram=A:1
Bit 17042081 0x004201a0   2977 Block=SLICE_X2Y46 Ram=A:3
Bit 17042082 0x004201a0   2978 Block=SLICE_X2Y46 Ram=A:5
Bit 17042083 0x004201a0   2979 Block=SLICE_X2Y46 Ram=A:7
Bit 17042084 0x004201a0   2980 Block=SLICE_X2Y46 Ram=A:17
Bit 17042085 0x004201a0   2981 Block=SLICE_X2Y46 Ram=A:19
Bit 17042086 0x004201a0   2982 Block=SLICE_X2Y46 Ram=A:21
Bit 17042087 0x004201a0   2983 Block=SLICE_X2Y46 Ram=A:23
Bit 17042088 0x004201a0   2984 Block=SLICE_X2Y46 Ram=A:33
Bit 17042089 0x004201a0   2985 Block=SLICE_X2Y46 Ram=A:35
Bit 17042090 0x004201a0   2986 Block=SLICE_X2Y46 Ram=A:37
Bit 17042091 0x004201a0   2987 Block=SLICE_X2Y46 Ram=A:39
Bit 17042092 0x004201a0   2988 Block=SLICE_X2Y46 Ram=A:49
Bit 17042093 0x004201a0   2989 Block=SLICE_X2Y46 Ram=A:51
Bit 17042094 0x004201a0   2990 Block=SLICE_X2Y46 Ram=A:53
Bit 17042095 0x004201a0   2991 Block=SLICE_X2Y46 Ram=A:55
Bit 17045312 0x004201a1   2976 Block=SLICE_X2Y46 Ram=A:0
Bit 17045313 0x004201a1   2977 Block=SLICE_X2Y46 Ram=A:2
Bit 17045314 0x004201a1   2978 Block=SLICE_X2Y46 Ram=A:4
Bit 17045315 0x004201a1   2979 Block=SLICE_X2Y46 Ram=A:6
Bit 17045316 0x004201a1   2980 Block=SLICE_X2Y46 Ram=A:16
Bit 17045317 0x004201a1   2981 Block=SLICE_X2Y46 Ram=A:18
Bit 17045318 0x004201a1   2982 Block=SLICE_X2Y46 Ram=A:20
Bit 17045319 0x004201a1   2983 Block=SLICE_X2Y46 Ram=A:22
Bit 17045320 0x004201a1   2984 Block=SLICE_X2Y46 Ram=A:32
Bit 17045321 0x004201a1   2985 Block=SLICE_X2Y46 Ram=A:34
Bit 17045322 0x004201a1   2986 Block=SLICE_X2Y46 Ram=A:36
Bit 17045323 0x004201a1   2987 Block=SLICE_X2Y46 Ram=A:38
Bit 17045324 0x004201a1   2988 Block=SLICE_X2Y46 Ram=A:48
Bit 17045325 0x004201a1   2989 Block=SLICE_X2Y46 Ram=A:50
Bit 17045326 0x004201a1   2990 Block=SLICE_X2Y46 Ram=A:52
Bit 17045327 0x004201a1   2991 Block=SLICE_X2Y46 Ram=A:54
Bit 17048544 0x004201a2   2976 Block=SLICE_X2Y46 Ram=A:9
Bit 17048545 0x004201a2   2977 Block=SLICE_X2Y46 Ram=A:11
Bit 17048546 0x004201a2   2978 Block=SLICE_X2Y46 Ram=A:13
Bit 17048547 0x004201a2   2979 Block=SLICE_X2Y46 Ram=A:15
Bit 17048548 0x004201a2   2980 Block=SLICE_X2Y46 Ram=A:25
Bit 17048549 0x004201a2   2981 Block=SLICE_X2Y46 Ram=A:27
Bit 17048550 0x004201a2   2982 Block=SLICE_X2Y46 Ram=A:29
Bit 17048551 0x004201a2   2983 Block=SLICE_X2Y46 Ram=A:31
Bit 17048552 0x004201a2   2984 Block=SLICE_X2Y46 Ram=A:41
Bit 17048553 0x004201a2   2985 Block=SLICE_X2Y46 Ram=A:43
Bit 17048554 0x004201a2   2986 Block=SLICE_X2Y46 Ram=A:45
Bit 17048555 0x004201a2   2987 Block=SLICE_X2Y46 Ram=A:47
Bit 17048556 0x004201a2   2988 Block=SLICE_X2Y46 Ram=A:57
Bit 17048557 0x004201a2   2989 Block=SLICE_X2Y46 Ram=A:59
Bit 17048558 0x004201a2   2990 Block=SLICE_X2Y46 Ram=A:61
Bit 17048559 0x004201a2   2991 Block=SLICE_X2Y46 Ram=A:63
Bit 17051776 0x004201a3   2976 Block=SLICE_X2Y46 Ram=A:8
Bit 17051777 0x004201a3   2977 Block=SLICE_X2Y46 Ram=A:10
Bit 17051778 0x004201a3   2978 Block=SLICE_X2Y46 Ram=A:12
Bit 17051779 0x004201a3   2979 Block=SLICE_X2Y46 Ram=A:14
Bit 17051780 0x004201a3   2980 Block=SLICE_X2Y46 Ram=A:24
Bit 17051781 0x004201a3   2981 Block=SLICE_X2Y46 Ram=A:26
Bit 17051782 0x004201a3   2982 Block=SLICE_X2Y46 Ram=A:28
Bit 17051783 0x004201a3   2983 Block=SLICE_X2Y46 Ram=A:30
Bit 17051784 0x004201a3   2984 Block=SLICE_X2Y46 Ram=A:40
Bit 17051785 0x004201a3   2985 Block=SLICE_X2Y46 Ram=A:42
Bit 17051786 0x004201a3   2986 Block=SLICE_X2Y46 Ram=A:44
Bit 17051787 0x004201a3   2987 Block=SLICE_X2Y46 Ram=A:46
Bit 17051788 0x004201a3   2988 Block=SLICE_X2Y46 Ram=A:56
Bit 17051789 0x004201a3   2989 Block=SLICE_X2Y46 Ram=A:58
Bit 17051790 0x004201a3   2990 Block=SLICE_X2Y46 Ram=A:60
Bit 17051791 0x004201a3   2991 Block=SLICE_X2Y46 Ram=A:62
Bit 19353027 0x00420c1f   3043 Block=SLICE_X34Y47 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[0]
Bit 19353028 0x00420c1f   3044 Block=SLICE_X35Y47 Latch=AQ Net=fast_heartbeat/data_o_OBUF[0]
Bit 19353052 0x00420c1f   3068 Block=SLICE_X34Y47 Latch=BQ Net=fast_heartbeat/heartbeat_count_reg[1]
Bit 19353057 0x00420c1f   3073 Block=SLICE_X34Y47 Latch=CQ Net=fast_heartbeat/heartbeat_count_reg[2]
Bit 19353082 0x00420c1f   3098 Block=SLICE_X34Y47 Latch=DQ Net=fast_heartbeat/heartbeat_count_reg[3]
Bit 19353091 0x00420c1f   3107 Block=SLICE_X34Y48 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[4]
Bit 19353116 0x00420c1f   3132 Block=SLICE_X34Y48 Latch=BQ Net=fast_heartbeat/heartbeat_count_reg[5]
Bit 19353121 0x00420c1f   3137 Block=SLICE_X34Y48 Latch=CQ Net=fast_heartbeat/heartbeat_count_reg[6]
Bit 19353146 0x00420c1f   3162 Block=SLICE_X34Y48 Latch=DQ Net=fast_heartbeat/heartbeat_count_reg[7]
Bit 19353155 0x00420c1f   3171 Block=SLICE_X34Y49 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[8]
Bit 19353180 0x00420c1f   3196 Block=SLICE_X34Y49 Latch=BQ Net=fast_heartbeat/heartbeat_count_reg[9]
Bit 19353185 0x00420c1f   3201 Block=SLICE_X34Y49 Latch=CQ Net=fast_heartbeat/heartbeat_count_reg[10]
Bit 19353210 0x00420c1f   3226 Block=SLICE_X34Y49 Latch=DQ Net=fast_heartbeat/heartbeat_count_reg[11]
Bit 11056675 0x00400c1f      3 Block=SLICE_X34Y50 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[12]
Bit 11056700 0x00400c1f     28 Block=SLICE_X34Y50 Latch=BQ Net=fast_heartbeat/heartbeat_count_reg[13]
Bit 11056705 0x00400c1f     33 Block=SLICE_X34Y50 Latch=CQ Net=fast_heartbeat/heartbeat_count_reg[14]
Bit 11056730 0x00400c1f     58 Block=SLICE_X34Y50 Latch=DQ Net=fast_heartbeat/heartbeat_count_reg[15]
Bit 11056739 0x00400c1f     67 Block=SLICE_X34Y51 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[16]
Bit 11056764 0x00400c1f     92 Block=SLICE_X34Y51 Latch=BQ Net=fast_heartbeat/heartbeat_count_reg[17]
Bit 11056769 0x00400c1f     97 Block=SLICE_X34Y51 Latch=CQ Net=fast_heartbeat/heartbeat_count_reg[18]
Bit 11056794 0x00400c1f    122 Block=SLICE_X34Y51 Latch=DQ Net=fast_heartbeat/heartbeat_count_reg[19]
Bit 11056803 0x00400c1f    131 Block=SLICE_X34Y52 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[20]
Bit 11056804 0x00400c1f    132 Block=SLICE_X35Y52 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[24]
Bit 11056828 0x00400c1f    156 Block=SLICE_X34Y52 Latch=BQ Net=fast_heartbeat/heartbeat_count_reg[21]
Bit 11056833 0x00400c1f    161 Block=SLICE_X34Y52 Latch=CQ Net=fast_heartbeat/heartbeat_count_reg[22]
Bit 11056858 0x00400c1f    186 Block=SLICE_X34Y52 Latch=DQ Net=fast_heartbeat/heartbeat_count_reg[23]
Bit 20257988 0x0042101f   3044 Block=SLICE_X49Y47 Latch=AQ Net=slow_heartbeat/data_o_OBUF[0]
Bit 11961699 0x0040101f     67 Block=SLICE_X48Y51 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[24]
Bit 11961724 0x0040101f     92 Block=SLICE_X48Y51 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[25]
Bit 11961729 0x0040101f     97 Block=SLICE_X48Y51 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[26]
Bit 20471236 0x0042111f   2980 Block=SLICE_X51Y46 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[0]
Bit 20471261 0x0042111f   3005 Block=SLICE_X51Y46 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[1]
Bit 20471266 0x0042111f   3010 Block=SLICE_X51Y46 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[2]
Bit 20471291 0x0042111f   3035 Block=SLICE_X51Y46 Latch=DQ Net=slow_heartbeat/heartbeat_count_reg[3]
Bit 20471300 0x0042111f   3044 Block=SLICE_X51Y47 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[4]
Bit 20471325 0x0042111f   3069 Block=SLICE_X51Y47 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[5]
Bit 20471330 0x0042111f   3074 Block=SLICE_X51Y47 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[6]
Bit 20471355 0x0042111f   3099 Block=SLICE_X51Y47 Latch=DQ Net=slow_heartbeat/heartbeat_count_reg[7]
Bit 20471364 0x0042111f   3108 Block=SLICE_X51Y48 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[8]
Bit 20471389 0x0042111f   3133 Block=SLICE_X51Y48 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[9]
Bit 20471394 0x0042111f   3138 Block=SLICE_X51Y48 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[10]
Bit 20471419 0x0042111f   3163 Block=SLICE_X51Y48 Latch=DQ Net=slow_heartbeat/heartbeat_count_reg[11]
Bit 20471428 0x0042111f   3172 Block=SLICE_X51Y49 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[12]
Bit 20471453 0x0042111f   3197 Block=SLICE_X51Y49 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[13]
Bit 20471458 0x0042111f   3202 Block=SLICE_X51Y49 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[14]
Bit 20471483 0x0042111f   3227 Block=SLICE_X51Y49 Latch=DQ Net=slow_heartbeat/heartbeat_count_reg[15]
Bit 12174948 0x0040111f      4 Block=SLICE_X51Y50 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[16]
Bit 12174973 0x0040111f     29 Block=SLICE_X51Y50 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[17]
Bit 12174978 0x0040111f     34 Block=SLICE_X51Y50 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[18]
Bit 12175003 0x0040111f     59 Block=SLICE_X51Y50 Latch=DQ Net=slow_heartbeat/heartbeat_count_reg[19]
Bit 12175012 0x0040111f     68 Block=SLICE_X51Y51 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[20]
Bit 12175037 0x0040111f     93 Block=SLICE_X51Y51 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[21]
Bit 12175042 0x0040111f     98 Block=SLICE_X51Y51 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[22]
Bit 12175066 0x0040111f    122 Block=SLICE_X50Y51 Latch=DQ Net=slow_heartbeat/p_0_in[24]
Bit 12175067 0x0040111f    123 Block=SLICE_X51Y51 Latch=DQ Net=slow_heartbeat/heartbeat_count_reg[23]
