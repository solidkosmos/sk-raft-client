Revision 3
; Created by bitgen 2025.2 at Thu Nov 26 12:07:10 2026
; Bit lines have the following form:
; <offset> <frame address> <frame offset> <information>
; <information> may be zero or more <kw>=<value> pairs
; Block=<blockname     specifies the block associated with this
;                      memory cell.
;
; Latch=<name>         specifies the latch associated with this memory cell.
;
; Net=<netname>        specifies the user net associated with this
;                      memory cell.
;
; COMPARE=[YES | NO]   specifies whether or not it is appropriate
;                      to compare this bit position between a
;                      "program" and a "readback" bitstream.
;                      If not present the default is NO.
;
; Ram=<ram id>:<bit>   This is used in cases where a CLB function
; Rom=<ram id>:<bit>   generator is used as RAM (or ROM).  <Ram id>
;                      will be either 'F', 'G', or 'M', indicating
;                      that it is part of a single F or G function
;                      generator used as RAM, or as a single RAM
;                      (or ROM) built from both F and G.  <Bit> is
;                      a decimal number.
;
; Info lines have the following form:
; Info <name>=<value>  specifies a bit associated with the LCA
;                      configuration options, and the value of
;                      that bit.  The names of these bits may have
;                      special meaning to software reading the .ll file.
;
Info STARTSEL0=1
Bit 17038854 0x0042019f   2982 Block=SLICE_X2Y46 Latch=A5FF.Q Net=clk_gen_inst/seq_reg_reg_n_0_[7]
Bit 17042080 0x004201a0   2976 Block=SLICE_X2Y46 Ram=A:1
Bit 17042081 0x004201a0   2977 Block=SLICE_X2Y46 Ram=A:3
Bit 17042082 0x004201a0   2978 Block=SLICE_X2Y46 Ram=A:5
Bit 17042083 0x004201a0   2979 Block=SLICE_X2Y46 Ram=A:7
Bit 17042084 0x004201a0   2980 Block=SLICE_X2Y46 Ram=A:17
Bit 17042085 0x004201a0   2981 Block=SLICE_X2Y46 Ram=A:19
Bit 17042086 0x004201a0   2982 Block=SLICE_X2Y46 Ram=A:21
Bit 17042087 0x004201a0   2983 Block=SLICE_X2Y46 Ram=A:23
Bit 17042088 0x004201a0   2984 Block=SLICE_X2Y46 Ram=A:33
Bit 17042089 0x004201a0   2985 Block=SLICE_X2Y46 Ram=A:35
Bit 17042090 0x004201a0   2986 Block=SLICE_X2Y46 Ram=A:37
Bit 17042091 0x004201a0   2987 Block=SLICE_X2Y46 Ram=A:39
Bit 17042092 0x004201a0   2988 Block=SLICE_X2Y46 Ram=A:49
Bit 17042093 0x004201a0   2989 Block=SLICE_X2Y46 Ram=A:51
Bit 17042094 0x004201a0   2990 Block=SLICE_X2Y46 Ram=A:53
Bit 17042095 0x004201a0   2991 Block=SLICE_X2Y46 Ram=A:55
Bit 17045312 0x004201a1   2976 Block=SLICE_X2Y46 Ram=A:0
Bit 17045313 0x004201a1   2977 Block=SLICE_X2Y46 Ram=A:2
Bit 17045314 0x004201a1   2978 Block=SLICE_X2Y46 Ram=A:4
Bit 17045315 0x004201a1   2979 Block=SLICE_X2Y46 Ram=A:6
Bit 17045316 0x004201a1   2980 Block=SLICE_X2Y46 Ram=A:16
Bit 17045317 0x004201a1   2981 Block=SLICE_X2Y46 Ram=A:18
Bit 17045318 0x004201a1   2982 Block=SLICE_X2Y46 Ram=A:20
Bit 17045319 0x004201a1   2983 Block=SLICE_X2Y46 Ram=A:22
Bit 17045320 0x004201a1   2984 Block=SLICE_X2Y46 Ram=A:32
Bit 17045321 0x004201a1   2985 Block=SLICE_X2Y46 Ram=A:34
Bit 17045322 0x004201a1   2986 Block=SLICE_X2Y46 Ram=A:36
Bit 17045323 0x004201a1   2987 Block=SLICE_X2Y46 Ram=A:38
Bit 17045324 0x004201a1   2988 Block=SLICE_X2Y46 Ram=A:48
Bit 17045325 0x004201a1   2989 Block=SLICE_X2Y46 Ram=A:50
Bit 17045326 0x004201a1   2990 Block=SLICE_X2Y46 Ram=A:52
Bit 17045327 0x004201a1   2991 Block=SLICE_X2Y46 Ram=A:54
Bit 17048544 0x004201a2   2976 Block=SLICE_X2Y46 Ram=A:9
Bit 17048545 0x004201a2   2977 Block=SLICE_X2Y46 Ram=A:11
Bit 17048546 0x004201a2   2978 Block=SLICE_X2Y46 Ram=A:13
Bit 17048547 0x004201a2   2979 Block=SLICE_X2Y46 Ram=A:15
Bit 17048548 0x004201a2   2980 Block=SLICE_X2Y46 Ram=A:25
Bit 17048549 0x004201a2   2981 Block=SLICE_X2Y46 Ram=A:27
Bit 17048550 0x004201a2   2982 Block=SLICE_X2Y46 Ram=A:29
Bit 17048551 0x004201a2   2983 Block=SLICE_X2Y46 Ram=A:31
Bit 17048552 0x004201a2   2984 Block=SLICE_X2Y46 Ram=A:41
Bit 17048553 0x004201a2   2985 Block=SLICE_X2Y46 Ram=A:43
Bit 17048554 0x004201a2   2986 Block=SLICE_X2Y46 Ram=A:45
Bit 17048555 0x004201a2   2987 Block=SLICE_X2Y46 Ram=A:47
Bit 17048556 0x004201a2   2988 Block=SLICE_X2Y46 Ram=A:57
Bit 17048557 0x004201a2   2989 Block=SLICE_X2Y46 Ram=A:59
Bit 17048558 0x004201a2   2990 Block=SLICE_X2Y46 Ram=A:61
Bit 17048559 0x004201a2   2991 Block=SLICE_X2Y46 Ram=A:63
Bit 17051776 0x004201a3   2976 Block=SLICE_X2Y46 Ram=A:8
Bit 17051777 0x004201a3   2977 Block=SLICE_X2Y46 Ram=A:10
Bit 17051778 0x004201a3   2978 Block=SLICE_X2Y46 Ram=A:12
Bit 17051779 0x004201a3   2979 Block=SLICE_X2Y46 Ram=A:14
Bit 17051780 0x004201a3   2980 Block=SLICE_X2Y46 Ram=A:24
Bit 17051781 0x004201a3   2981 Block=SLICE_X2Y46 Ram=A:26
Bit 17051782 0x004201a3   2982 Block=SLICE_X2Y46 Ram=A:28
Bit 17051783 0x004201a3   2983 Block=SLICE_X2Y46 Ram=A:30
Bit 17051784 0x004201a3   2984 Block=SLICE_X2Y46 Ram=A:40
Bit 17051785 0x004201a3   2985 Block=SLICE_X2Y46 Ram=A:42
Bit 17051786 0x004201a3   2986 Block=SLICE_X2Y46 Ram=A:44
Bit 17051787 0x004201a3   2987 Block=SLICE_X2Y46 Ram=A:46
Bit 17051788 0x004201a3   2988 Block=SLICE_X2Y46 Ram=A:56
Bit 17051789 0x004201a3   2989 Block=SLICE_X2Y46 Ram=A:58
Bit 17051790 0x004201a3   2990 Block=SLICE_X2Y46 Ram=A:60
Bit 17051791 0x004201a3   2991 Block=SLICE_X2Y46 Ram=A:62
Bit 19353027 0x00420c1f   3043 Block=SLICE_X34Y47 Latch=AQ Net=shift_reg_0/mass_s_reg[0]
Bit 19353028 0x00420c1f   3044 Block=SLICE_X35Y47 Latch=AQ Net=shift_reg_0/mass_s_reg[10]
Bit 19353029 0x00420c1f   3045 Block=SLICE_X35Y47 Latch=A5FF.Q Net=shift_reg_0/mass_s_reg[6]
Bit 19353030 0x00420c1f   3046 Block=SLICE_X34Y47 Latch=A5FF.Q Net=shift_reg_0/mass_s_reg[1]
Bit 19353046 0x00420c1f   3062 Block=SLICE_X34Y47 Latch=B5FF.Q Net=shift_reg_0/mass_s_reg[2]
Bit 19353047 0x00420c1f   3063 Block=SLICE_X35Y47 Latch=B5FF.Q Net=shift_reg_0/mass_s_reg[7]
Bit 19353052 0x00420c1f   3068 Block=SLICE_X34Y47 Latch=BQ Net=shift_reg_0/mass_s_reg[13]
Bit 19353053 0x00420c1f   3069 Block=SLICE_X35Y47 Latch=BQ Net=shift_reg_0/mass_s_reg[11]
Bit 19353057 0x00420c1f   3073 Block=SLICE_X34Y47 Latch=CQ Net=shift_reg_0/mass_s_reg[14]
Bit 19353058 0x00420c1f   3074 Block=SLICE_X35Y47 Latch=CQ Net=shift_reg_0/mass_s_reg[12]
Bit 19353065 0x00420c1f   3081 Block=SLICE_X34Y47 Latch=C5FF.Q Net=shift_reg_0/mass_s_reg[3]
Bit 19353066 0x00420c1f   3082 Block=SLICE_X35Y47 Latch=C5FF.Q Net=shift_reg_0/mass_s_reg[8]
Bit 19353075 0x00420c1f   3091 Block=SLICE_X34Y47 Latch=D5FF.Q Net=shift_reg_0/mass_s_reg[4]
Bit 19353076 0x00420c1f   3092 Block=SLICE_X35Y47 Latch=D5FF.Q Net=shift_reg_0/mass_s_reg[9]
Bit 19353082 0x00420c1f   3098 Block=SLICE_X34Y47 Latch=DQ Net=shift_reg_0/mass_s_reg[15]
Bit 19353083 0x00420c1f   3099 Block=SLICE_X35Y47 Latch=DQ Net=shift_reg_0/mass_s_reg[5]
Bit 20471299 0x0042111f   3043 Block=SLICE_X50Y47 Latch=AQ Net=shift_reg_1/mass_s_reg[0]
Bit 20471300 0x0042111f   3044 Block=SLICE_X51Y47 Latch=AQ Net=shift_reg_1/mass_s_reg[10]
Bit 20471301 0x0042111f   3045 Block=SLICE_X51Y47 Latch=A5FF.Q Net=shift_reg_1/mass_s_reg[6]
Bit 20471302 0x0042111f   3046 Block=SLICE_X50Y47 Latch=A5FF.Q Net=shift_reg_1/mass_s_reg[1]
Bit 20471318 0x0042111f   3062 Block=SLICE_X50Y47 Latch=B5FF.Q Net=shift_reg_1/mass_s_reg[2]
Bit 20471319 0x0042111f   3063 Block=SLICE_X51Y47 Latch=B5FF.Q Net=shift_reg_1/mass_s_reg[7]
Bit 20471324 0x0042111f   3068 Block=SLICE_X50Y47 Latch=BQ Net=shift_reg_1/mass_s_reg[13]
Bit 20471325 0x0042111f   3069 Block=SLICE_X51Y47 Latch=BQ Net=shift_reg_1/mass_s_reg[11]
Bit 20471329 0x0042111f   3073 Block=SLICE_X50Y47 Latch=CQ Net=shift_reg_1/mass_s_reg[14]
Bit 20471330 0x0042111f   3074 Block=SLICE_X51Y47 Latch=CQ Net=shift_reg_1/mass_s_reg[12]
Bit 20471337 0x0042111f   3081 Block=SLICE_X50Y47 Latch=C5FF.Q Net=shift_reg_1/mass_s_reg[3]
Bit 20471338 0x0042111f   3082 Block=SLICE_X51Y47 Latch=C5FF.Q Net=shift_reg_1/mass_s_reg[8]
Bit 20471347 0x0042111f   3091 Block=SLICE_X50Y47 Latch=D5FF.Q Net=shift_reg_1/mass_s_reg[4]
Bit 20471348 0x0042111f   3092 Block=SLICE_X51Y47 Latch=D5FF.Q Net=shift_reg_1/mass_s_reg[9]
Bit 20471354 0x0042111f   3098 Block=SLICE_X50Y47 Latch=DQ Net=shift_reg_1/mass_s_reg[15]
Bit 20471355 0x0042111f   3099 Block=SLICE_X51Y47 Latch=DQ Net=shift_reg_1/mass_s_reg[5]
