Revision 3
; Created by bitgen 2025.2 at Wed Oct 21 13:17:00 2026
; Bit lines have the following form:
; <offset> <frame address> <frame offset> <information>
; <information> may be zero or more <kw>=<value> pairs
; Block=<blockname     specifies the block associated with this
;                      memory cell.
;
; Latch=<name>         specifies the latch associated with this memory cell.
;
; Net=<netname>        specifies the user net associated with this
;                      memory cell.
;
; COMPARE=[YES | NO]   specifies whether or not it is appropriate
;                      to compare this bit position between a
;                      "program" and a "readback" bitstream.
;                      If not present the default is NO.
;
; Ram=<ram id>:<bit>   This is used in cases where a CLB function
; Rom=<ram id>:<bit>   generator is used as RAM (or ROM).  <Ram id>
;                      will be either 'F', 'G', or 'M', indicating
;                      that it is part of a single F or G function
;                      generator used as RAM, or as a single RAM
;                      (or ROM) built from both F and G.  <Bit> is
;                      a decimal number.
;
; Info lines have the following form:
; Info <name>=<value>  specifies a bit associated with the LCA
;                      configuration options, and the value of
;                      that bit.  The names of these bits may have
;                      special meaning to software reading the .ll file.
;
Info STARTSEL0=1
Info BoundaryScanEnabled=1
Bit 11588675 0x00400a1f   1955 Block=SLICE_X30Y30 Latch=AQ Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[0]
Bit 11588676 0x00400a1f   1956 Block=SLICE_X31Y30 Latch=AQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[0]
Bit 11588678 0x00400a1f   1958 Block=SLICE_X30Y30 Latch=A5FF.Q Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[4]
Bit 11588694 0x00400a1f   1974 Block=SLICE_X30Y30 Latch=B5FF.Q Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[5]
Bit 11588700 0x00400a1f   1980 Block=SLICE_X30Y30 Latch=BQ Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[1]
Bit 11588701 0x00400a1f   1981 Block=SLICE_X31Y30 Latch=BQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[1]
Bit 11588705 0x00400a1f   1985 Block=SLICE_X30Y30 Latch=CQ Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[2]
Bit 11588706 0x00400a1f   1986 Block=SLICE_X31Y30 Latch=CQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[2]
Bit 11588713 0x00400a1f   1993 Block=SLICE_X30Y30 Latch=C5FF.Q Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[6]
Bit 11588723 0x00400a1f   2003 Block=SLICE_X30Y30 Latch=D5FF.Q Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[7]
Bit 11588730 0x00400a1f   2010 Block=SLICE_X30Y30 Latch=DQ Net=bscan_u1_operands/bscan_interface_read_write_uX/data_user_reg_data_in[3]
Bit 11588731 0x00400a1f   2011 Block=SLICE_X31Y30 Latch=DQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[7]
Bit 11588867 0x00400a1f   2147 Block=SLICE_X30Y33 Latch=AQ Net=bscan_u2_simplex_adder_res/bscan_interface_read_write_uX/ux_tdo
Bit 11588870 0x00400a1f   2150 Block=SLICE_X30Y33 Latch=A5FF.Q Net=bscan_u2_simplex_adder_res/bscan_interface_read_write_uX/p_2_in
Bit 11588886 0x00400a1f   2166 Block=SLICE_X30Y33 Latch=B5FF.Q Net=bscan_u2_simplex_adder_res/bscan_interface_read_write_uX/p_1_in
Bit 11588892 0x00400a1f   2172 Block=SLICE_X30Y33 Latch=BQ Net=bscan_u2_simplex_adder_res/bscan_interface_read_write_uX/p_0_in
Bit 11472259 0x0040099f   1891 Block=SLICE_X28Y29 Latch=AQ Net=bscan_u3_tmr_adder_res/bscan_interface_read_write_uX/data_user_reg_data_out_reg_n_0_[4]
Bit 11472260 0x0040099f   1892 Block=SLICE_X29Y29 Latch=AQ Net=bscan_u3_tmr_adder_res/bscan_interface_read_write_uX/ux_tdo
Bit 11472261 0x0040099f   1893 Block=SLICE_X29Y29 Latch=A5FF.Q Net=bscan_u3_tmr_adder_res/bscan_interface_read_write_uX/p_2_in
Bit 11472279 0x0040099f   1911 Block=SLICE_X29Y29 Latch=B5FF.Q Net=bscan_u3_tmr_adder_res/bscan_interface_read_write_uX/p_1_in
Bit 11472285 0x0040099f   1917 Block=SLICE_X29Y29 Latch=BQ Net=bscan_u3_tmr_adder_res/bscan_interface_read_write_uX/p_0_in
Bit 11472324 0x0040099f   1956 Block=SLICE_X29Y30 Latch=AQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[3]
Bit 11472349 0x0040099f   1981 Block=SLICE_X29Y30 Latch=BQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[4]
Bit 11472354 0x0040099f   1986 Block=SLICE_X29Y30 Latch=CQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[5]
Bit 11472379 0x0040099f   2011 Block=SLICE_X29Y30 Latch=DQ Net=bscan_u1_operands/bscan_interface_read_write_uX/Q[6]
Bit 11472387 0x0040099f   2019 Block=SLICE_X28Y31 Latch=AQ Net=bscan_u1_operands/bscan_interface_read_write_uX/FSM_onehot_check_rw_reg_n_0_[1]
Bit 11472390 0x0040099f   2022 Block=SLICE_X28Y31 Latch=A5FF.Q Net=bscan_u1_operands/bscan_interface_read_write_uX/FSM_onehot_check_rw_reg_n_0_[2]
Bit 11472412 0x0040099f   2044 Block=SLICE_X28Y31 Latch=BQ Net=bscan_u1_operands/bscan_interface_read_write_uX/FSM_onehot_check_rw_reg_n_0_[0]
Bit 11472417 0x0040099f   2049 Block=SLICE_X28Y31 Latch=CQ Net=bscan_u1_operands/bscan_interface_read_write_uX/rw_reg_0
Bit 11472516 0x0040099f   2148 Block=SLICE_X29Y33 Latch=AQ Net=bscan_u2_simplex_adder_res/bscan_interface_read_write_uX/data_user_reg_data_out_reg_n_0_[4]
