Revision 3
; Created by bitgen 2025.2 at Thu Nov 26 12:09:00 2026
; Bit lines have the following form:
; <offset> <frame address> <frame offset> <information>
; <information> may be zero or more <kw>=<value> pairs
; Block=<blockname     specifies the block associated with this
;                      memory cell.
;
; Latch=<name>         specifies the latch associated with this memory cell.
;
; Net=<netname>        specifies the user net associated with this
;                      memory cell.
;
; COMPARE=[YES | NO]   specifies whether or not it is appropriate
;                      to compare this bit position between a
;                      "program" and a "readback" bitstream.
;                      If not present the default is NO.
;
; Ram=<ram id>:<bit>   This is used in cases where a CLB function
; Rom=<ram id>:<bit>   generator is used as RAM (or ROM).  <Ram id>
;                      will be either 'F', 'G', or 'M', indicating
;                      that it is part of a single F or G function
;                      generator used as RAM, or as a single RAM
;                      (or ROM) built from both F and G.  <Bit> is
;                      a decimal number.
;
; Info lines have the following form:
; Info <name>=<value>  specifies a bit associated with the LCA
;                      configuration options, and the value of
;                      that bit.  The names of these bits may have
;                      special meaning to software reading the .ll file.
;
Info STARTSEL0=1
Bit  4586595 0x0000141f    387 Block=SLICE_X62Y56 Latch=AQ Net=shift_reg_1/mass_s_reg[0]
Bit  4586596 0x0000141f    388 Block=SLICE_X63Y56 Latch=AQ Net=shift_reg_1/mass_s_reg[2]
Bit  4586597 0x0000141f    389 Block=SLICE_X63Y56 Latch=A5FF.Q Net=shift_reg_1/mass_s_reg[6]
Bit  4586598 0x0000141f    390 Block=SLICE_X62Y56 Latch=A5FF.Q Net=shift_reg_1/mass_s_reg[13]
Bit  4586614 0x0000141f    406 Block=SLICE_X62Y56 Latch=B5FF.Q Net=shift_reg_1/mass_s_reg[14]
Bit  4586615 0x0000141f    407 Block=SLICE_X63Y56 Latch=B5FF.Q Net=shift_reg_1/mass_s_reg[7]
Bit  4586620 0x0000141f    412 Block=SLICE_X62Y56 Latch=BQ Net=shift_reg_1/mass_s_reg[10]
Bit  4586621 0x0000141f    413 Block=SLICE_X63Y56 Latch=BQ Net=shift_reg_1/mass_s_reg[3]
Bit  4586625 0x0000141f    417 Block=SLICE_X62Y56 Latch=CQ Net=shift_reg_1/mass_s_reg[11]
Bit  4586626 0x0000141f    418 Block=SLICE_X63Y56 Latch=CQ Net=shift_reg_1/mass_s_reg[4]
Bit  4586633 0x0000141f    425 Block=SLICE_X62Y56 Latch=C5FF.Q Net=shift_reg_1/mass_s_reg[15]
Bit  4586634 0x0000141f    426 Block=SLICE_X63Y56 Latch=C5FF.Q Net=shift_reg_1/mass_s_reg[8]
Bit  4586643 0x0000141f    435 Block=SLICE_X62Y56 Latch=D5FF.Q Net=shift_reg_1/mass_s_reg[1]
Bit  4586644 0x0000141f    436 Block=SLICE_X63Y56 Latch=D5FF.Q Net=shift_reg_1/mass_s_reg[9]
Bit  4586650 0x0000141f    442 Block=SLICE_X62Y56 Latch=DQ Net=shift_reg_1/mass_s_reg[12]
Bit  4586651 0x0000141f    443 Block=SLICE_X63Y56 Latch=DQ Net=shift_reg_1/mass_s_reg[5]
Bit  4032963 0x0000119f   2659 Block=SLICE_X54Y91 Latch=AQ Net=shift_reg_0/mass_s_reg[0]
Bit  4032964 0x0000119f   2660 Block=SLICE_X55Y91 Latch=AQ Net=shift_reg_0/mass_s_reg[2]
Bit  4032965 0x0000119f   2661 Block=SLICE_X55Y91 Latch=A5FF.Q Net=shift_reg_0/mass_s_reg[6]
Bit  4032966 0x0000119f   2662 Block=SLICE_X54Y91 Latch=A5FF.Q Net=shift_reg_0/mass_s_reg[13]
Bit  4032982 0x0000119f   2678 Block=SLICE_X54Y91 Latch=B5FF.Q Net=shift_reg_0/mass_s_reg[14]
Bit  4032983 0x0000119f   2679 Block=SLICE_X55Y91 Latch=B5FF.Q Net=shift_reg_0/mass_s_reg[7]
Bit  4032988 0x0000119f   2684 Block=SLICE_X54Y91 Latch=BQ Net=shift_reg_0/mass_s_reg[10]
Bit  4032989 0x0000119f   2685 Block=SLICE_X55Y91 Latch=BQ Net=shift_reg_0/mass_s_reg[3]
Bit  4032993 0x0000119f   2689 Block=SLICE_X54Y91 Latch=CQ Net=shift_reg_0/mass_s_reg[11]
Bit  4032994 0x0000119f   2690 Block=SLICE_X55Y91 Latch=CQ Net=shift_reg_0/mass_s_reg[4]
Bit  4033001 0x0000119f   2697 Block=SLICE_X54Y91 Latch=C5FF.Q Net=shift_reg_0/mass_s_reg[15]
Bit  4033002 0x0000119f   2698 Block=SLICE_X55Y91 Latch=C5FF.Q Net=shift_reg_0/mass_s_reg[8]
Bit  4033011 0x0000119f   2707 Block=SLICE_X54Y91 Latch=D5FF.Q Net=shift_reg_0/mass_s_reg[1]
Bit  4033012 0x0000119f   2708 Block=SLICE_X55Y91 Latch=D5FF.Q Net=shift_reg_0/mass_s_reg[9]
Bit  4033018 0x0000119f   2714 Block=SLICE_X54Y91 Latch=DQ Net=shift_reg_0/mass_s_reg[12]
Bit  4033019 0x0000119f   2715 Block=SLICE_X55Y91 Latch=DQ Net=shift_reg_0/mass_s_reg[5]
Bit 12152070 0x00400c9f   2982 Block=SLICE_X38Y46 Latch=A5FF.Q Net=clk_gen_inst/seq_reg_reg_n_0_[7]
Bit 12155296 0x00400ca0   2976 Block=SLICE_X38Y46 Ram=A:1
Bit 12155297 0x00400ca0   2977 Block=SLICE_X38Y46 Ram=A:3
Bit 12155298 0x00400ca0   2978 Block=SLICE_X38Y46 Ram=A:5
Bit 12155299 0x00400ca0   2979 Block=SLICE_X38Y46 Ram=A:7
Bit 12155300 0x00400ca0   2980 Block=SLICE_X38Y46 Ram=A:17
Bit 12155301 0x00400ca0   2981 Block=SLICE_X38Y46 Ram=A:19
Bit 12155302 0x00400ca0   2982 Block=SLICE_X38Y46 Ram=A:21
Bit 12155303 0x00400ca0   2983 Block=SLICE_X38Y46 Ram=A:23
Bit 12155304 0x00400ca0   2984 Block=SLICE_X38Y46 Ram=A:33
Bit 12155305 0x00400ca0   2985 Block=SLICE_X38Y46 Ram=A:35
Bit 12155306 0x00400ca0   2986 Block=SLICE_X38Y46 Ram=A:37
Bit 12155307 0x00400ca0   2987 Block=SLICE_X38Y46 Ram=A:39
Bit 12155308 0x00400ca0   2988 Block=SLICE_X38Y46 Ram=A:49
Bit 12155309 0x00400ca0   2989 Block=SLICE_X38Y46 Ram=A:51
Bit 12155310 0x00400ca0   2990 Block=SLICE_X38Y46 Ram=A:53
Bit 12155311 0x00400ca0   2991 Block=SLICE_X38Y46 Ram=A:55
Bit 12158528 0x00400ca1   2976 Block=SLICE_X38Y46 Ram=A:0
Bit 12158529 0x00400ca1   2977 Block=SLICE_X38Y46 Ram=A:2
Bit 12158530 0x00400ca1   2978 Block=SLICE_X38Y46 Ram=A:4
Bit 12158531 0x00400ca1   2979 Block=SLICE_X38Y46 Ram=A:6
Bit 12158532 0x00400ca1   2980 Block=SLICE_X38Y46 Ram=A:16
Bit 12158533 0x00400ca1   2981 Block=SLICE_X38Y46 Ram=A:18
Bit 12158534 0x00400ca1   2982 Block=SLICE_X38Y46 Ram=A:20
Bit 12158535 0x00400ca1   2983 Block=SLICE_X38Y46 Ram=A:22
Bit 12158536 0x00400ca1   2984 Block=SLICE_X38Y46 Ram=A:32
Bit 12158537 0x00400ca1   2985 Block=SLICE_X38Y46 Ram=A:34
Bit 12158538 0x00400ca1   2986 Block=SLICE_X38Y46 Ram=A:36
Bit 12158539 0x00400ca1   2987 Block=SLICE_X38Y46 Ram=A:38
Bit 12158540 0x00400ca1   2988 Block=SLICE_X38Y46 Ram=A:48
Bit 12158541 0x00400ca1   2989 Block=SLICE_X38Y46 Ram=A:50
Bit 12158542 0x00400ca1   2990 Block=SLICE_X38Y46 Ram=A:52
Bit 12158543 0x00400ca1   2991 Block=SLICE_X38Y46 Ram=A:54
Bit 12161760 0x00400ca2   2976 Block=SLICE_X38Y46 Ram=A:9
Bit 12161761 0x00400ca2   2977 Block=SLICE_X38Y46 Ram=A:11
Bit 12161762 0x00400ca2   2978 Block=SLICE_X38Y46 Ram=A:13
Bit 12161763 0x00400ca2   2979 Block=SLICE_X38Y46 Ram=A:15
Bit 12161764 0x00400ca2   2980 Block=SLICE_X38Y46 Ram=A:25
Bit 12161765 0x00400ca2   2981 Block=SLICE_X38Y46 Ram=A:27
Bit 12161766 0x00400ca2   2982 Block=SLICE_X38Y46 Ram=A:29
Bit 12161767 0x00400ca2   2983 Block=SLICE_X38Y46 Ram=A:31
Bit 12161768 0x00400ca2   2984 Block=SLICE_X38Y46 Ram=A:41
Bit 12161769 0x00400ca2   2985 Block=SLICE_X38Y46 Ram=A:43
Bit 12161770 0x00400ca2   2986 Block=SLICE_X38Y46 Ram=A:45
Bit 12161771 0x00400ca2   2987 Block=SLICE_X38Y46 Ram=A:47
Bit 12161772 0x00400ca2   2988 Block=SLICE_X38Y46 Ram=A:57
Bit 12161773 0x00400ca2   2989 Block=SLICE_X38Y46 Ram=A:59
Bit 12161774 0x00400ca2   2990 Block=SLICE_X38Y46 Ram=A:61
Bit 12161775 0x00400ca2   2991 Block=SLICE_X38Y46 Ram=A:63
Bit 12164992 0x00400ca3   2976 Block=SLICE_X38Y46 Ram=A:8
Bit 12164993 0x00400ca3   2977 Block=SLICE_X38Y46 Ram=A:10
Bit 12164994 0x00400ca3   2978 Block=SLICE_X38Y46 Ram=A:12
Bit 12164995 0x00400ca3   2979 Block=SLICE_X38Y46 Ram=A:14
Bit 12164996 0x00400ca3   2980 Block=SLICE_X38Y46 Ram=A:24
Bit 12164997 0x00400ca3   2981 Block=SLICE_X38Y46 Ram=A:26
Bit 12164998 0x00400ca3   2982 Block=SLICE_X38Y46 Ram=A:28
Bit 12164999 0x00400ca3   2983 Block=SLICE_X38Y46 Ram=A:30
Bit 12165000 0x00400ca3   2984 Block=SLICE_X38Y46 Ram=A:40
Bit 12165001 0x00400ca3   2985 Block=SLICE_X38Y46 Ram=A:42
Bit 12165002 0x00400ca3   2986 Block=SLICE_X38Y46 Ram=A:44
Bit 12165003 0x00400ca3   2987 Block=SLICE_X38Y46 Ram=A:46
Bit 12165004 0x00400ca3   2988 Block=SLICE_X38Y46 Ram=A:56
Bit 12165005 0x00400ca3   2989 Block=SLICE_X38Y46 Ram=A:58
Bit 12165006 0x00400ca3   2990 Block=SLICE_X38Y46 Ram=A:60
Bit 12165007 0x00400ca3   2991 Block=SLICE_X38Y46 Ram=A:62
