Revision 3
; Created by bitgen 2025.2 at Wed Oct 21 13:13:49 2026
; Bit lines have the following form:
; <offset> <frame address> <frame offset> <information>
; <information> may be zero or more <kw>=<value> pairs
; Block=<blockname     specifies the block associated with this
;                      memory cell.
;
; Latch=<name>         specifies the latch associated with this memory cell.
;
; Net=<netname>        specifies the user net associated with this
;                      memory cell.
;
; COMPARE=[YES | NO]   specifies whether or not it is appropriate
;                      to compare this bit position between a
;                      "program" and a "readback" bitstream.
;                      If not present the default is NO.
;
; Ram=<ram id>:<bit>   This is used in cases where a CLB function
; Rom=<ram id>:<bit>   generator is used as RAM (or ROM).  <Ram id>
;                      will be either 'F', 'G', or 'M', indicating
;                      that it is part of a single F or G function
;                      generator used as RAM, or as a single RAM
;                      (or ROM) built from both F and G.  <Bit> is
;                      a decimal number.
;
; Info lines have the following form:
; Info <name>=<value>  specifies a bit associated with the LCA
;                      configuration options, and the value of
;                      that bit.  The names of these bits may have
;                      special meaning to software reading the .ll file.
;
Info STARTSEL0=1
Bit  4702947 0x0000149f    387 Block=SLICE_X64Y56 Latch=AQ Net=slow_heartbeat/data_o_OBUF[0]
Bit  4586596 0x0000141f    388 Block=SLICE_X63Y56 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[0]
Bit  4586621 0x0000141f    413 Block=SLICE_X63Y56 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[1]
Bit  4586626 0x0000141f    418 Block=SLICE_X63Y56 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[2]
Bit  4586651 0x0000141f    443 Block=SLICE_X63Y56 Latch=DQ Net=slow_heartbeat/heartbeat_count_reg[3]
Bit  4586660 0x0000141f    452 Block=SLICE_X63Y57 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[4]
Bit  4586685 0x0000141f    477 Block=SLICE_X63Y57 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[5]
Bit  4586690 0x0000141f    482 Block=SLICE_X63Y57 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[6]
Bit  4586715 0x0000141f    507 Block=SLICE_X63Y57 Latch=DQ Net=slow_heartbeat/heartbeat_count_reg[7]
Bit  4586724 0x0000141f    516 Block=SLICE_X63Y58 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[8]
Bit  4586749 0x0000141f    541 Block=SLICE_X63Y58 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[9]
Bit  4586754 0x0000141f    546 Block=SLICE_X63Y58 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[10]
Bit  4586779 0x0000141f    571 Block=SLICE_X63Y58 Latch=DQ Net=slow_heartbeat/heartbeat_count_reg[11]
Bit  4586788 0x0000141f    580 Block=SLICE_X63Y59 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[12]
Bit  4586813 0x0000141f    605 Block=SLICE_X63Y59 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[13]
Bit  4586818 0x0000141f    610 Block=SLICE_X63Y59 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[14]
Bit  4586843 0x0000141f    635 Block=SLICE_X63Y59 Latch=DQ Net=slow_heartbeat/heartbeat_count_reg[15]
Bit  4586852 0x0000141f    644 Block=SLICE_X63Y60 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[16]
Bit  4586877 0x0000141f    669 Block=SLICE_X63Y60 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[17]
Bit  4586882 0x0000141f    674 Block=SLICE_X63Y60 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[18]
Bit  4586907 0x0000141f    699 Block=SLICE_X63Y60 Latch=DQ Net=slow_heartbeat/heartbeat_count_reg[19]
Bit  4586916 0x0000141f    708 Block=SLICE_X63Y61 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[20]
Bit  4586941 0x0000141f    733 Block=SLICE_X63Y61 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[21]
Bit  4586946 0x0000141f    738 Block=SLICE_X63Y61 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[22]
Bit  4586971 0x0000141f    763 Block=SLICE_X63Y61 Latch=DQ Net=slow_heartbeat/heartbeat_count_reg[23]
Bit  4586980 0x0000141f    772 Block=SLICE_X63Y62 Latch=AQ Net=slow_heartbeat/heartbeat_count_reg[24]
Bit  4587005 0x0000141f    797 Block=SLICE_X63Y62 Latch=BQ Net=slow_heartbeat/heartbeat_count_reg[25]
Bit  4587010 0x0000141f    802 Block=SLICE_X63Y62 Latch=CQ Net=slow_heartbeat/heartbeat_count_reg[26]
Bit  4149379 0x0000121f   2723 Block=SLICE_X56Y92 Latch=AQ Net=fast_heartbeat/data_o_OBUF[0]
Bit  4032964 0x0000119f   2660 Block=SLICE_X55Y91 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[0]
Bit  4032989 0x0000119f   2685 Block=SLICE_X55Y91 Latch=BQ Net=fast_heartbeat/heartbeat_count_reg[1]
Bit  4032994 0x0000119f   2690 Block=SLICE_X55Y91 Latch=CQ Net=fast_heartbeat/heartbeat_count_reg[2]
Bit  4033019 0x0000119f   2715 Block=SLICE_X55Y91 Latch=DQ Net=fast_heartbeat/heartbeat_count_reg[3]
Bit  4033028 0x0000119f   2724 Block=SLICE_X55Y92 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[4]
Bit  4033053 0x0000119f   2749 Block=SLICE_X55Y92 Latch=BQ Net=fast_heartbeat/heartbeat_count_reg[5]
Bit  4033058 0x0000119f   2754 Block=SLICE_X55Y92 Latch=CQ Net=fast_heartbeat/heartbeat_count_reg[6]
Bit  4033083 0x0000119f   2779 Block=SLICE_X55Y92 Latch=DQ Net=fast_heartbeat/heartbeat_count_reg[7]
Bit  4033092 0x0000119f   2788 Block=SLICE_X55Y93 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[8]
Bit  4033117 0x0000119f   2813 Block=SLICE_X55Y93 Latch=BQ Net=fast_heartbeat/heartbeat_count_reg[9]
Bit  4033122 0x0000119f   2818 Block=SLICE_X55Y93 Latch=CQ Net=fast_heartbeat/heartbeat_count_reg[10]
Bit  4033147 0x0000119f   2843 Block=SLICE_X55Y93 Latch=DQ Net=fast_heartbeat/heartbeat_count_reg[11]
Bit  4033156 0x0000119f   2852 Block=SLICE_X55Y94 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[12]
Bit  4033181 0x0000119f   2877 Block=SLICE_X55Y94 Latch=BQ Net=fast_heartbeat/heartbeat_count_reg[13]
Bit  4033186 0x0000119f   2882 Block=SLICE_X55Y94 Latch=CQ Net=fast_heartbeat/heartbeat_count_reg[14]
Bit  4033211 0x0000119f   2907 Block=SLICE_X55Y94 Latch=DQ Net=fast_heartbeat/heartbeat_count_reg[15]
Bit  4033220 0x0000119f   2916 Block=SLICE_X55Y95 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[16]
Bit  4033245 0x0000119f   2941 Block=SLICE_X55Y95 Latch=BQ Net=fast_heartbeat/heartbeat_count_reg[17]
Bit  4033250 0x0000119f   2946 Block=SLICE_X55Y95 Latch=CQ Net=fast_heartbeat/heartbeat_count_reg[18]
Bit  4033275 0x0000119f   2971 Block=SLICE_X55Y95 Latch=DQ Net=fast_heartbeat/heartbeat_count_reg[19]
Bit  4033284 0x0000119f   2980 Block=SLICE_X55Y96 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[20]
Bit  4033309 0x0000119f   3005 Block=SLICE_X55Y96 Latch=BQ Net=fast_heartbeat/heartbeat_count_reg[21]
Bit  4033314 0x0000119f   3010 Block=SLICE_X55Y96 Latch=CQ Net=fast_heartbeat/heartbeat_count_reg[22]
Bit  4033339 0x0000119f   3035 Block=SLICE_X55Y96 Latch=DQ Net=fast_heartbeat/heartbeat_count_reg[23]
Bit  4033348 0x0000119f   3044 Block=SLICE_X55Y97 Latch=AQ Net=fast_heartbeat/heartbeat_count_reg[24]
Bit 12152070 0x00400c9f   2982 Block=SLICE_X38Y46 Latch=A5FF.Q Net=clk_gen_inst/seq_reg_reg_n_0_[7]
Bit 12155296 0x00400ca0   2976 Block=SLICE_X38Y46 Ram=A:1
Bit 12155297 0x00400ca0   2977 Block=SLICE_X38Y46 Ram=A:3
Bit 12155298 0x00400ca0   2978 Block=SLICE_X38Y46 Ram=A:5
Bit 12155299 0x00400ca0   2979 Block=SLICE_X38Y46 Ram=A:7
Bit 12155300 0x00400ca0   2980 Block=SLICE_X38Y46 Ram=A:17
Bit 12155301 0x00400ca0   2981 Block=SLICE_X38Y46 Ram=A:19
Bit 12155302 0x00400ca0   2982 Block=SLICE_X38Y46 Ram=A:21
Bit 12155303 0x00400ca0   2983 Block=SLICE_X38Y46 Ram=A:23
Bit 12155304 0x00400ca0   2984 Block=SLICE_X38Y46 Ram=A:33
Bit 12155305 0x00400ca0   2985 Block=SLICE_X38Y46 Ram=A:35
Bit 12155306 0x00400ca0   2986 Block=SLICE_X38Y46 Ram=A:37
Bit 12155307 0x00400ca0   2987 Block=SLICE_X38Y46 Ram=A:39
Bit 12155308 0x00400ca0   2988 Block=SLICE_X38Y46 Ram=A:49
Bit 12155309 0x00400ca0   2989 Block=SLICE_X38Y46 Ram=A:51
Bit 12155310 0x00400ca0   2990 Block=SLICE_X38Y46 Ram=A:53
Bit 12155311 0x00400ca0   2991 Block=SLICE_X38Y46 Ram=A:55
Bit 12158528 0x00400ca1   2976 Block=SLICE_X38Y46 Ram=A:0
Bit 12158529 0x00400ca1   2977 Block=SLICE_X38Y46 Ram=A:2
Bit 12158530 0x00400ca1   2978 Block=SLICE_X38Y46 Ram=A:4
Bit 12158531 0x00400ca1   2979 Block=SLICE_X38Y46 Ram=A:6
Bit 12158532 0x00400ca1   2980 Block=SLICE_X38Y46 Ram=A:16
Bit 12158533 0x00400ca1   2981 Block=SLICE_X38Y46 Ram=A:18
Bit 12158534 0x00400ca1   2982 Block=SLICE_X38Y46 Ram=A:20
Bit 12158535 0x00400ca1   2983 Block=SLICE_X38Y46 Ram=A:22
Bit 12158536 0x00400ca1   2984 Block=SLICE_X38Y46 Ram=A:32
Bit 12158537 0x00400ca1   2985 Block=SLICE_X38Y46 Ram=A:34
Bit 12158538 0x00400ca1   2986 Block=SLICE_X38Y46 Ram=A:36
Bit 12158539 0x00400ca1   2987 Block=SLICE_X38Y46 Ram=A:38
Bit 12158540 0x00400ca1   2988 Block=SLICE_X38Y46 Ram=A:48
Bit 12158541 0x00400ca1   2989 Block=SLICE_X38Y46 Ram=A:50
Bit 12158542 0x00400ca1   2990 Block=SLICE_X38Y46 Ram=A:52
Bit 12158543 0x00400ca1   2991 Block=SLICE_X38Y46 Ram=A:54
Bit 12161760 0x00400ca2   2976 Block=SLICE_X38Y46 Ram=A:9
Bit 12161761 0x00400ca2   2977 Block=SLICE_X38Y46 Ram=A:11
Bit 12161762 0x00400ca2   2978 Block=SLICE_X38Y46 Ram=A:13
Bit 12161763 0x00400ca2   2979 Block=SLICE_X38Y46 Ram=A:15
Bit 12161764 0x00400ca2   2980 Block=SLICE_X38Y46 Ram=A:25
Bit 12161765 0x00400ca2   2981 Block=SLICE_X38Y46 Ram=A:27
Bit 12161766 0x00400ca2   2982 Block=SLICE_X38Y46 Ram=A:29
Bit 12161767 0x00400ca2   2983 Block=SLICE_X38Y46 Ram=A:31
Bit 12161768 0x00400ca2   2984 Block=SLICE_X38Y46 Ram=A:41
Bit 12161769 0x00400ca2   2985 Block=SLICE_X38Y46 Ram=A:43
Bit 12161770 0x00400ca2   2986 Block=SLICE_X38Y46 Ram=A:45
Bit 12161771 0x00400ca2   2987 Block=SLICE_X38Y46 Ram=A:47
Bit 12161772 0x00400ca2   2988 Block=SLICE_X38Y46 Ram=A:57
Bit 12161773 0x00400ca2   2989 Block=SLICE_X38Y46 Ram=A:59
Bit 12161774 0x00400ca2   2990 Block=SLICE_X38Y46 Ram=A:61
Bit 12161775 0x00400ca2   2991 Block=SLICE_X38Y46 Ram=A:63
Bit 12164992 0x00400ca3   2976 Block=SLICE_X38Y46 Ram=A:8
Bit 12164993 0x00400ca3   2977 Block=SLICE_X38Y46 Ram=A:10
Bit 12164994 0x00400ca3   2978 Block=SLICE_X38Y46 Ram=A:12
Bit 12164995 0x00400ca3   2979 Block=SLICE_X38Y46 Ram=A:14
Bit 12164996 0x00400ca3   2980 Block=SLICE_X38Y46 Ram=A:24
Bit 12164997 0x00400ca3   2981 Block=SLICE_X38Y46 Ram=A:26
Bit 12164998 0x00400ca3   2982 Block=SLICE_X38Y46 Ram=A:28
Bit 12164999 0x00400ca3   2983 Block=SLICE_X38Y46 Ram=A:30
Bit 12165000 0x00400ca3   2984 Block=SLICE_X38Y46 Ram=A:40
Bit 12165001 0x00400ca3   2985 Block=SLICE_X38Y46 Ram=A:42
Bit 12165002 0x00400ca3   2986 Block=SLICE_X38Y46 Ram=A:44
Bit 12165003 0x00400ca3   2987 Block=SLICE_X38Y46 Ram=A:46
Bit 12165004 0x00400ca3   2988 Block=SLICE_X38Y46 Ram=A:56
Bit 12165005 0x00400ca3   2989 Block=SLICE_X38Y46 Ram=A:58
Bit 12165006 0x00400ca3   2990 Block=SLICE_X38Y46 Ram=A:60
Bit 12165007 0x00400ca3   2991 Block=SLICE_X38Y46 Ram=A:62
